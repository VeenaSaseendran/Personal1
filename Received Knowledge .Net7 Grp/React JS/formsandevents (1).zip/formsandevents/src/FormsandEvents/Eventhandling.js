import React, { Component } from 'react'

export default class Eventhandling extends Component 
{

    state={
        product : "Mobile",
        price : 23000
    }
   
    constructor()
    {
        super()
        this.updatePrice=this.updatePrice.bind(this);
    }


  render() 
  {
    return (

      <div>
           <h1>Product : {this.state.product}</h1>
           <p>Price : {this.state.price}</p>

           <input id="price" type="number" />
           <button onClick={this.updatePrice}>Update the Price
           </button>
      </div>
    )
  }


  updatePrice(e)
  {
    let cost=document.getElementById("price").value;
    console.log(cost);

    // this.setState
    // ({
    //     price:cost
    // })

    this.setState
    ({
        price:cost
    },()=>{
        console.log(this.state);
    })

  }

}
