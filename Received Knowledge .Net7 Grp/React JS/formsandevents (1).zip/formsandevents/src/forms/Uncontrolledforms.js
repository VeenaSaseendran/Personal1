import React, { Component } from 'react'

export default class Uncontrolledforms extends Component {

    submitFormHandler = event => {
        event.preventDefault();
        
        //this will fetch value with a tag named "name"
        console.dir(this.refs.name.value); 
    }

  render() {
    return (
      <div>
        <u><h3>uncontrolled input forms Example</h3></u>
        <form >
          <div>
            <input type="text" name="name" ref="name" />
          </div>
          <button onClick={this.submitFormHandler}>submit</button>
        </form>
      </div>
    )
  }
}
