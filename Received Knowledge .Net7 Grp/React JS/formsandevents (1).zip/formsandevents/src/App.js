import './App.css';
import Forms from './FormsandEvents/forms';
import Eventhandling from './FormsandEvents/Eventhandling';
import Uncontrolledforms from './forms/Uncontrolledforms';
import Controlledforms from './forms/Controlledforms';

function App() {
  return (
    <div className="App">

      <Uncontrolledforms/><br></br>
      <Controlledforms/><br></br>
      <Forms/> <br></br>
      <Eventhandling/><br></br>
    </div>
  );
}

export default App;
