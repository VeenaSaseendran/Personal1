export default {
    GET_POSTS: "GET_POSTS",
};
