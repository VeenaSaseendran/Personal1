import React, { Component } from 'react'

export default class Controlledforms extends Component {

    constructor () {
        super()
        this.state = {
          email: ''
        }
      }

    changeHandler = event => {
        this.setState({
          email: event.target.value
        });
        console.log(this.state.email)
      }

  render() {
    return (
      <div>
        <u><h3>Controlled Input form</h3></u><br></br>
        <form>
          <input type="email" 
                 name="email"   
                 value={this.state.email} 
                 onChange={this.changeHandler} 
          />
      </form>
      </div>
    )
  }
}
