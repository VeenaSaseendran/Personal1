import React from "react";

function Home() {
    return (
        <div className="jumbotron">
            <h1 class="display-4">Welcome to the BlogApp</h1>
            <p class="lead">This is a Home page of BlogApp.</p>
        </div>
    );
}

export default Home;
