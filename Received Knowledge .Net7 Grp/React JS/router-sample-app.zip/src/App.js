import './App.css';
import Home from './pages/Home';
import Blogs from './pages/Blogs';
import Contact from './pages/Contact';
import Layout from './pages/Layout';
import NoPage from './pages/NoPage';
//HashRouter  -   URL should not (or cannot) be sent to the server for some reason
                  //In these situations, <HashRouter> makes it possible to store the current 
                  //location in the hash portion of the current URL, so it is never sent to the server.
//MemoryRouter -  URL wont show in browser as it is
                  //stores its locations internally in an array 
//BrowserRouter - Stores the current location in the browser's address bar using 
                  //clean URLs and navigates using the browser's built-in history stack.
import { HashRouter,Routes,Route } from 'react-router-dom';

function App() {
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="blogs" element={<Blogs />} />
          <Route path="contact" element={<Contact />} />          
          <Route path="*" element={<NoPage />} />
        </Route>
      </Routes>
    </HashRouter>
  );
}
export default App;