const Blogs = () => {
    return ( 
        <div className="container col-md-12 mt-3">
             <h1 style={{color: "#414141"}}>React Bolgs</h1> 
             <hr />
             <img class="col-md-6" src="./Image/blogs1.png" alt=""></img>   
             <img class="col-md-6" src="./Image/blogs2.png" alt=""></img>   
             <img class="col-md-6" src="./Image/blogs3.png" alt=""></img>   
        </div>
    )}
  export default Blogs;