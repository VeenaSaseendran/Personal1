import React, { Component } from 'react'

export default class Forms extends Component {

    constructor(props){
        super(props)
         this.state={
            number:''
         }
    }

    NumberChange=(e)=>
    {
        this.setState({
            number:e.target.value
        })
    }


  render() {
    return (
      <div>
        <h1>React Forms</h1>
        <label>Enter Number</label>
        <input 
        type='text' 
        value={this.state.number} 
        onChange={this.NumberChange}/><br></br>
        Updated Number:
        <h3>{this.state.number}</h3>
      </div>
    )
  }
}
